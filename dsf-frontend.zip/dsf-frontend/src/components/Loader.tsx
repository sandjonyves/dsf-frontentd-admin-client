import { BounceLoader } from "react-spinners"

const Loader = () => {
  return (
    <BounceLoader color="var(--primary-color)" />
  )
}

export default Loader