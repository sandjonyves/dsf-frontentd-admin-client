//export const BASE_URL = 'https://ztbtsgvqkn.us-east-2.awsapprunner.com/api/v1/';
export const BASE_URL = 'https://dsf-backend.onrender.com'
// 'http://localhost:8000/api/v1/';
