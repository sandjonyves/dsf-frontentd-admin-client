export { default as Dashboard } from './Dashboard' 
export { default as Login } from './Login' 
export { default as Register } from './Register' 